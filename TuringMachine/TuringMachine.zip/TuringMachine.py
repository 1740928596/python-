import numpy as np
tapeLength = 1000
maxIter = 9999
class TuringMachine:
    '''
    初始化图灵机，读入程序和输入
    '''
    def __init__(self, programFile):
        # tap 是一个长度为tapeLength的数组
        self.tape = np.zeros(tapeLength)
        self.state = 0
        # head初始化在tape中间的位置
        self.head = tapeLength // 2
        self.program = self.buildProgram(programFile)
        # 如果在小于maxIter停止，halt = True；如果在maxIter未停止或有其他方法判定为非停时，halt = False
        self.halt = True
    def buildProgram(self, programFile):
        '''
        :param programFile: 一个N行程序，具体格式参照Great Ideas in Computer Science P164 M_add
        :return: 自行设计合适的数据结构，存储每一条instruction，方便调用；example：Nx2数组，每个数组包含(i,R,j)或者(i,L,j)
        '''
    def step(self):
        '''
        执行一条指令，更新head, tape, state
        '''
    def run(self, input):
        '''
        执行整个程序，得到运算结果
        '''
    def getTuringResult(self):
        '''
        :return: 从非零元素开始的tape序列，
        例如整体序列为......000111110000.....，则输入'11111'
        '''
        return '11111'

    def getCurrentStateString(self):
        '''
        设计字符串格式输出当前状态、位置、tape状态
        '''
    def visualize(self):
        '''
        （选做）使用matplotlib动态展示图灵机的更新过程
        '''